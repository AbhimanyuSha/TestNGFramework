package pages;

import org.openqa.selenium.By;

public class ValidateLinkObject {


	public static final By NEWCUSTOMER = By.xpath("//a[contains(text(),'New Customer')]");
	public static final By MINISTATEMENT = By.xpath("//a[contains(text(),'Mini Statement')]");

}