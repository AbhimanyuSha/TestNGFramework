package newtoursAutomation;

import org.openqa.selenium.By;

public class LogOffObject {

	static final By LOGOFF = By.xpath("//a[contains(text(),'SIGN-OFF')]");


}
