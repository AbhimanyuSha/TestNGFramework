package newtoursAutomation;

import org.openqa.selenium.WebDriver;

public class ValidateLinkAction {

	public void Links(WebDriver driver) 
	{

		try {	
			driver.findElement(ValidateLinkObject.ITINERARY).click();
			String title1 = driver.getTitle().trim();
			if(title1.equalsIgnoreCase("Select a Flight: Mercury Tours")){
				System.out.println("Link1 Validated");
			} else{
				System.out.println("Link1 validation Failed");
			}
			
			driver.findElement(ValidateLinkObject.CRUISES).click();
			String title2 = driver.getTitle().trim();
			if(title2.equalsIgnoreCase("Cruises: Mercury Tours")){
				System.out.println("Link2 Validated");
			} else{
				System.out.println("Link2 validation Failed");
			}
			
			
		} catch (Exception e) {			
			e.printStackTrace();
		} finally {
					
		}

	}
}
