package newtoursAutomation;

import org.openqa.selenium.WebDriver;

public class LogOffAction {

	public void userLogoff(WebDriver driver) 
	{

		try {	

			driver.findElement(LogOffObject.LOGOFF).click();

			String title = driver.getTitle().trim();
			if(title.equalsIgnoreCase("Sign-on: Mercury Tours")){
				System.out.println("SignOut Successful, now it's time to LogOff");
			} else{
				System.out.println("Test Case Failed");
			}
		} catch (Exception e) {			
			e.printStackTrace();
		} 		

	}

}
