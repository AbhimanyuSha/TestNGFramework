package newtoursAutomation;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class InitiateDriver 
{
	WebDriver driver = null;
	
	WebDriver DriverInitiate() 
	{
		System.setProperty("webdriver.chrome.driver", "C:/Users/cog-asha/Desktop/chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		return driver;
	}
}
