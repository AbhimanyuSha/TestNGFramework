package newtoursAutomation;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.JavascriptExecutor; 

public class LoginAction 
{
	public void userLogin(WebDriver driver,String userName,String password) 
	{
		
		try {	
			driver.findElement(LoginObject.USERNAMETEXTBOX).sendKeys(userName);
			driver.findElement(LoginObject.PASSWORDTEXTBOX).sendKeys(password);
			driver.findElement(LoginObject.LOGINBTN).click();

			WebDriverWait wait = new WebDriverWait(driver, 30);

			// wait for Javascript to load
			ExpectedCondition<Boolean> jsLoad = new ExpectedCondition<Boolean>() 
			{
				@Override
				public Boolean apply(WebDriver driver) {
					return (((JavascriptExecutor) driver).executeScript ("return document.readyState").toString().equals("complete"));
				}

			};
			wait.until(jsLoad);
			String title = driver.getTitle().trim();
			if(title.equalsIgnoreCase("Find a Flight: Mercury Tours:")){
				System.out.println("Login Successful, now it's time to find the flights buddy");
			} else{
				System.out.println("Test Case Failed");
			}
		} catch (Exception e) {			
			e.printStackTrace();
		} 		
	}



}
