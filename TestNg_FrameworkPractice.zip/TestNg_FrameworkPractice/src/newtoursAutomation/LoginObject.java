package newtoursAutomation;

import org.openqa.selenium.By;

public class LoginObject 
{
	static final By USERNAMETEXTBOX = By.name("userName");
	static final By PASSWORDTEXTBOX = By.name("password");
	static final By LOGINBTN = By.name("login");
}
