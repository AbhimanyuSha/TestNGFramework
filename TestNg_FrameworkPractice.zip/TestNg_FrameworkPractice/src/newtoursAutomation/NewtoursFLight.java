package newtoursAutomation;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class NewtoursFLight
{
	public static void main(String[] args) 
	{
		WebDriver driver=null;
		try {

			LoginAction login = new LoginAction();
			System.setProperty("webdriver.chrome.driver", "C:/Users/cog-asha/Desktop/chromedriver.exe");
			driver = new ChromeDriver();
			driver.manage().window().maximize();

			driver.get("http://newtours.demoaut.com/");

			login.userLogin(driver, "Peter@F", "101010");

			ValidateLinkAction validateLink = new ValidateLinkAction();
			validateLink.Links(driver);

			LogOffAction validateSignout = new LogOffAction();
			validateSignout.userLogoff(driver);

		}
		catch(Exception e) {
			e.printStackTrace();
		}finally {
			driver.close();	
		}


	}
}
