package newtoursAutomation;

import org.openqa.selenium.By;

public class ValidateLinkObject {


	static final By ITINERARY = By.xpath("//a[contains(text(),'ITINERARY')]");
	static final By CRUISES = By.xpath("//a[contains(text(),'Cruises')]");

}