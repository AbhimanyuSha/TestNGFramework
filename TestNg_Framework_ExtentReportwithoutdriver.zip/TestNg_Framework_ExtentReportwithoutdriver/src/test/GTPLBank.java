package test;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import base.CaptureScreenshot;
import base.InitiateDriver;
import pages.LogOffObject;
import pages.LoginObject;
import pages.ValidateLinkObject;

public class GTPLBank extends InitiateDriver
{
	public WebDriver driver = DriverInitiate();
	public ExtentTest test;
	public ExtentReports report;
	CaptureScreenshot scrsht = new CaptureScreenshot();

	@BeforeTest (alwaysRun = true)
	public void startTest()
	{
		report = new ExtentReports("ExtentReportResults.html");
		test = report.startTest("GTPLBank");

	}

	@Test (priority = 1, groups = { "Regression" })
	public void Login() 
	{

		try {	

			driver.findElement(LoginObject.USERNAMETEXTBOX).sendKeys(props.getProperty("Username"));
			driver.findElement(LoginObject.PASSWORDTEXTBOX).sendKeys(props.getProperty("Password"));
			driver.findElement(LoginObject.LOGINBTN).click();

			/*WebDriverWait wait = new WebDriverWait(driver, 30);

			// wait for Javascript to load
			ExpectedCondition<Boolean> jsLoad = new ExpectedCondition<Boolean>() 
			{
				@Override
				public Boolean apply(WebDriver driver) {
					return (((JavascriptExecutor) driver).executeScript ("return document.readyState").toString().equals("complete"));
				}

			};
			wait.until(jsLoad);
			Thread.sleep(10000);*/

			String title = driver.getTitle().trim();

			Assert.assertTrue(title.equalsIgnoreCase("GTPL Bank Manager HomePage"));
			if(title.equalsIgnoreCase("GTPL Bank Manager HomePage")){
				System.out.println("Login Successful, now it's time to check your account");
				test.log(LogStatus.PASS, "Login Successful, now it's time to check your account",test.addScreenCapture(scrsht.captureString(driver)));

				//scrsht.capture(driver);



			} else{
				System.out.println("Test Case Failed");
				test.log(LogStatus.FAIL, "Test Case Failed",test.addScreenCapture(scrsht.captureString(driver)));

				//scrsht.capture(driver);

			}
		} catch (Exception e) {			
			e.printStackTrace();
		} 		
	}

	@Test (priority = 2, groups = { "Regression" }) 
	public void ValidateLink() 
	{

		try {	
			driver.findElement(ValidateLinkObject.NEWCUSTOMER).click();
			String title1 = driver.getTitle().trim();

			Assert.assertTrue(title1.equalsIgnoreCase("Gtpl Bank New Customer Entry Page"));
			if(title1.equalsIgnoreCase("Gtpl Bank New Customer Entry Page")){
				System.out.println("Link1 Validated");
				test.log(LogStatus.PASS, "Link1 Validated",test.addScreenCapture(scrsht.captureString(driver)));

				//scrsht.capture(driver);

			} else{
				System.out.println("Link1 validation Failed");
				test.log(LogStatus.FAIL, "Test Case Failed",test.addScreenCapture(scrsht.captureString(driver)));

				//scrsht.capture(driver);

			}

			Thread.sleep(2500);
			driver.findElement(ValidateLinkObject.MINISTATEMENT).click();
			String title2 = driver.getTitle().trim();

			Assert.assertTrue(title2.equalsIgnoreCase("GTPL Bank Mini Statement Page"));
			if(title2.equalsIgnoreCase("GTPL Bank Mini Statement Page")){
				System.out.println("Link2 Validated");
				test.log(LogStatus.PASS, "Link2 Validated",test.addScreenCapture(scrsht.captureString(driver)));

				//scrsht.capture(driver);

			} else{
				System.out.println("Link2 validation Failed");
				test.log(LogStatus.FAIL, "Test Case Failed",test.addScreenCapture(scrsht.captureString(driver)));

				//scrsht.capture(driver);

			}
		} catch (Exception e) {			
			e.printStackTrace();
		} 
	}

	@Test (priority = 3, groups = { "Regression" }) 
	public void LogOff() 
	{

		try {	

			driver.findElement(LogOffObject.LOGOFF).click();
			driver.switchTo().alert().dismiss();
			String title = driver.getTitle().trim();

			Assert.assertTrue(title.equalsIgnoreCase("GTPL Bank Home Page"));
			if(title.equalsIgnoreCase("GTPL Bank Home Page")){
				System.out.println("SignOut Successful, now it's time to LogOff");
				test.log(LogStatus.PASS, "SignOut Successful, now it's time to LogOff",test.addScreenCapture(scrsht.captureString(driver)));

				//scrsht.capture(driver);

			} else{
				System.out.println("Test Case Failed");
				test.log(LogStatus.FAIL, "Test Case Failed",test.addScreenCapture(scrsht.captureString(driver)));

				//scrsht.capture(driver);

			}
		} catch (Exception e) {			
			e.printStackTrace();
		} 	


	}


	@AfterTest (alwaysRun = true)
	public void tearDown() {
		driver.quit();
		report.endTest(test);
		report.flush();

	}


}

