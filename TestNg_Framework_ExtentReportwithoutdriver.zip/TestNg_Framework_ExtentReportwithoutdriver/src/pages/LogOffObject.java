package pages;

import org.openqa.selenium.By;

public class LogOffObject {

	public static final By LOGOFF = By.xpath("//ul[@class='menusubnav']//a[contains(text(),'Log out')]");


}
