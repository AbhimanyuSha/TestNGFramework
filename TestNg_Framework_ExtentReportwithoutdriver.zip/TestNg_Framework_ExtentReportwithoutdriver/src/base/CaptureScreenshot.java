package base;

import java.io.File;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class CaptureScreenshot{

	public String capture(WebDriver driver){

		String errflpath=null;
		try {
			File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			File Dest = new File("Screenshots//ScreenShot_" + System.currentTimeMillis()
			+ ".png");
			errflpath = Dest.getAbsolutePath();

			FileUtils.copyFile(scrFile, Dest);
		} catch (Exception e) {

			e.printStackTrace();
		}
		return errflpath;

	}

	public String captureString(WebDriver driver){
		String screenshot = "<img class='report-img' data-featherlight='image' src='data:image/png;base64,"
				+ ((TakesScreenshot) driver).getScreenshotAs(OutputType.BASE64)
				+ "' data-featherlight-after-content='this.$content.attr(\"src\",this.$source.attr(\"src\"))'/>";

		return screenshot;
	}
}
