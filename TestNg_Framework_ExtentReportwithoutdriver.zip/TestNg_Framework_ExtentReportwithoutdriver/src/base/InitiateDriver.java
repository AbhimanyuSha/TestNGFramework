package base;

import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class InitiateDriver 
{
	public WebDriver driver;
	/*public ExtentTest test;
	public ExtentReports report;*/
	
	public LoadProperties access = new LoadProperties();
	public Properties props = access.AccessPropertyFile();
	
	public WebDriver DriverInitiate() 
	{
		/*report = new ExtentReports("ExtentReportResults.html");
		test = report.startTest("GTPLBank");*/
				
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get(props.getProperty("URL"));
		
		return driver;
	}
}
