package test;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import base.InitiateDriver;
import pages.LogOffObject;
import pages.LoginObject;
import pages.ValidateLinkObject;

public class NewtoursFLight extends InitiateDriver
{
	
	public WebDriver driver = DriverInitiate();
		
	
	@Test
	public void Login() 
	{
		try {	
			
			driver.findElement(LoginObject.USERNAMETEXTBOX).sendKeys(props.getProperty("Username"));
			driver.findElement(LoginObject.PASSWORDTEXTBOX).sendKeys(props.getProperty("Password"));
			driver.findElement(LoginObject.LOGINBTN).click();

			WebDriverWait wait = new WebDriverWait(driver, 30);

			// wait for Javascript to load
			ExpectedCondition<Boolean> jsLoad = new ExpectedCondition<Boolean>() 
			{
				@Override
				public Boolean apply(WebDriver driver) {
					return (((JavascriptExecutor) driver).executeScript ("return document.readyState").toString().equals("complete"));
				}

			};
			wait.until(jsLoad);
			Thread.sleep(10000);
			String title = driver.getTitle().trim();
			
			Assert.assertTrue(title.equalsIgnoreCase("Find a Flight: Mercury Tours:"));
			if(title.equalsIgnoreCase("Find a Flight: Mercury Tours:")){
				System.out.println("Login Successful, now it's time to find the flights buddy");
			} else{
				System.out.println("Test Case Failed");
			}
		} catch (Exception e) {			
			e.printStackTrace();
		} 		
	}

	@Test
	public void ValidateLink() 
	{
		try {	
			driver.findElement(ValidateLinkObject.ITINERARY).click();
			String title1 = driver.getTitle().trim();
			
			Assert.assertTrue(title1.equalsIgnoreCase("Select a Flight: Mercury Tours"));
			if(title1.equalsIgnoreCase("Select a Flight: Mercury Tours")){
				System.out.println("Link1 Validated");
			} else{
				System.out.println("Link1 validation Failed");
			}

			driver.findElement(ValidateLinkObject.CRUISES).click();
			String title2 = driver.getTitle().trim();
			
			Assert.assertTrue(title2.equalsIgnoreCase("Cruises: Mercury Tours"));
			if(title2.equalsIgnoreCase("Cruises: Mercury Tours")){
				System.out.println("Link2 Validated");
			} else{
				System.out.println("Link2 validation Failed");
			}
		} catch (Exception e) {			
			e.printStackTrace();
		} 
	}

	@Test
	public void LogOff() 
	{
		try {	

			driver.findElement(LogOffObject.LOGOFF).click();

			String title = driver.getTitle().trim();
			
			Assert.assertTrue(title.equalsIgnoreCase("Sign-on: Mercury Tours"));
			if(title.equalsIgnoreCase("Sign-on: Mercury Tours")){
				System.out.println("SignOut Successful, now it's time to LogOff");
			} else{
				System.out.println("Test Case Failed");
			}
		} catch (Exception e) {			
			e.printStackTrace();
		} 	

	}

	@AfterTest
	public void tearDown() {
		driver.close();
	}


}

