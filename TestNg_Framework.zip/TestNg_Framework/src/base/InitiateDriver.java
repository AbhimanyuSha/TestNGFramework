package base;

import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class InitiateDriver 
{
	public WebDriver driver;
	
	public LoadProperties access = new LoadProperties();
	public Properties props = access.AccessPropertyFile();
	public WebDriver DriverInitiate() 
	{
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get(props.getProperty("URL"));
		
		return driver;
	}
}
