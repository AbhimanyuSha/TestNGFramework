package pages;

import org.openqa.selenium.By;

public class ValidateLinkObject {


	public static final By ITINERARY = By.xpath("//a[contains(text(),'ITINERARY')]");
	public static final By CRUISES = By.xpath("//a[contains(text(),'Cruises')]");

}