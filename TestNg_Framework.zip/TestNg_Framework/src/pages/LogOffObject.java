package pages;

import org.openqa.selenium.By;

public class LogOffObject {

	public static final By LOGOFF = By.xpath("//a[contains(text(),'SIGN-OFF')]");


}
