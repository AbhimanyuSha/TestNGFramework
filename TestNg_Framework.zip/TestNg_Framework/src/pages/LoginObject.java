package pages;

import org.openqa.selenium.By;

public class LoginObject 
{
	public static final By USERNAMETEXTBOX = By.name("userName");
	public static final By PASSWORDTEXTBOX = By.name("password");
	public static final By LOGINBTN = By.name("login");
}
